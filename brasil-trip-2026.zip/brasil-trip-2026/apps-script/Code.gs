/**
 * BRASIL TRIP 2026 — Travel ERP
 * Backend: Google Apps Script + Google Sheets (JSONP API)
 *
 * DEPLOY:
 * 1. Crear una Google Sheet nueva.
 * 2. Extensiones > Apps Script. Pegar este archivo (reemplazar Code.gs).
 * 3. Ejecutar la función `setupSheets` una vez (autorizar permisos).
 * 4. Implementar > Nueva implementación > Tipo: Aplicación web.
 *    - Ejecutar como: Yo
 *    - Quién tiene acceso: Cualquier usuario
 * 5. Copiar la URL /exec resultante y pegarla en public/js/config.js
 */

// ------------------------------------------------------------------
// CONFIGURACIÓN DE HOJAS
// ------------------------------------------------------------------

const SHEETS = {
  Config: ['key', 'value'],
  Travelers: ['id', 'name'],
  CashTransactions: ['id', 'date', 'type', 'concept', 'category', 'amount', 'currency', 'responsible', 'paymentMethod', 'receipt', 'notes'],
  Expenses: ['id', 'date', 'description', 'category', 'subcategory', 'amount', 'currency', 'paidFromCash', 'responsible', 'paymentMethod', 'receipt', 'notes'],
  Budget: ['id', 'category', 'budgetAmount', 'currency'],
  Routes: ['id', 'label', 'leg', 'origin', 'waypoint', 'destination', 'km', 'hours', 'tolls', 'hotelCost', 'fuelCost', 'totalCost', 'estimated', 'notes'],
  Tasks: ['id', 'task', 'category', 'responsible', 'dueDate', 'priority', 'status', 'cost', 'notes'],
  Purchases: ['id', 'product', 'category', 'quantity', 'estPrice', 'realPrice', 'responsible', 'dueDate', 'status'],
  Maintenance: ['id', 'item', 'status', 'date', 'mileage', 'responsible', 'estCost', 'realCost', 'dueDate', 'notes'],
  Itinerary: ['id', 'date', 'place', 'activity', 'time', 'duration', 'category', 'responsible', 'estCost', 'realCost', 'status', 'notes'],
  Luggage: ['id', 'item', 'quantity', 'person', 'category', 'packed'],
  Inventory: ['id', 'item', 'quantity', 'owner', 'category', 'status', 'notes'],
  Documents: ['id', 'name', 'category', 'status', 'notes']
};

const DEFAULT_CONFIG = {
  tripName: 'BRASIL 2026',
  travelerA: 'Matias',
  travelerB: 'Juli',
  origin: 'Corrientes Capital, Argentina',
  destination: 'Praia Brava, Florianópolis, Santa Catarina, Brasil',
  departureDate: '2026-11-19',
  departureTime: '05:00',
  arrivalDate: '2026-11-20',
  checkIn: '2026-11-20T15:00',
  checkOutLimit: '2026-11-30T12:00',
  plannedReturnDeparture: '2026-11-30T05:00',
  accommodationAddress: 'Avenida Tom Traugott Wildi, Ap 205, Bloco D, Florianópolis, Santa Catarina 88056, Brasil',
  vehicleBrand: 'Ford',
  vehicleModel: 'Fiesta 1.6 S Plus',
  vehicleYear: '2019',
  vehicleFuelType: 'Nafta',
  tankRangeKm: '600',
  tankCostARS: '100000',
  fuelMarginPercent: '10',
  vehicleMileage: '',
  vehicleNextService: '',
  accommodationTotalPrice: '447.60',
  accommodationCurrency: 'USD',
  accommodationDeposit: '',
  accommodationPaid: '',
  accommodationPending: '',
  accommodationPaymentDate: '',
  accommodationLink: 'https://www.airbnb.com.ar/trips/v1/1761904941603597708/ro/RESERVATION2_CHECKIN/HM4BPNQR29',
  accommodationContact: 'Fernando (anfitrión Airbnb) — coanfitriona Maila',
  accommodationConfirmationCode: 'HM4BPNQR29',
  accommodationGuests: '2',
  accommodationCheckInMethod: 'Cerradura inteligente (instrucciones 48hs antes)',
  accommodationCancellationPolicy: 'Cancelación gratuita hasta 15:00 del 21/10/2026. Reembolso parcial cancelando hasta 15:00 del 13/11/2026.',
  tripStatus: 'pre-viaje'
};

// ------------------------------------------------------------------
// SETUP
// ------------------------------------------------------------------

function setupSheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(SHEETS).forEach(function (name) {
    let sheet = ss.getSheetByName(name);
    if (!sheet) sheet = ss.insertSheet(name);
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(SHEETS[name]);
      sheet.setFrozenRows(1);
    }
  });
  // Seed default sheet if empty
  const def = ss.getSheets()[0];
  if (def.getName() === 'Hoja 1' || def.getName() === 'Sheet1') {
    ss.deleteSheet(def);
  }
  // Seed config
  const configSheet = ss.getSheetByName('Config');
  if (configSheet.getLastRow() <= 1) {
    Object.keys(DEFAULT_CONFIG).forEach(function (k) {
      configSheet.appendRow([k, DEFAULT_CONFIG[k]]);
    });
  }
  // Seed travelers
  const travSheet = ss.getSheetByName('Travelers');
  if (travSheet.getLastRow() <= 1) {
    travSheet.appendRow([1, 'Matias']);
    travSheet.appendRow([2, 'Juli']);
  }
}

// ------------------------------------------------------------------
// HELPERS
// ------------------------------------------------------------------

function getSheet_(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(name);
  if (!sheet) throw new Error('Hoja no encontrada: ' + name);
  return sheet;
}

function sheetToObjects_(name) {
  const sheet = getSheet_(name);
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0];
  const rows = values.slice(1);
  return rows
    .filter(function (r) { return r.join('') !== ''; })
    .map(function (r) {
      const obj = {};
      headers.forEach(function (h, i) { obj[h] = r[i]; });
      return obj;
    });
}

function nextId_(name) {
  const objs = sheetToObjects_(name);
  if (objs.length === 0) return 1;
  const ids = objs.map(function (o) { return Number(o.id) || 0; });
  return Math.max.apply(null, ids) + 1;
}

function appendRow_(name, obj) {
  const sheet = getSheet_(name);
  const headers = SHEETS[name];
  if (headers.indexOf('id') !== -1 && !obj.id) {
    obj.id = nextId_(name);
  }
  const row = headers.map(function (h) { return obj[h] !== undefined ? obj[h] : ''; });
  sheet.appendRow(row);
  return obj;
}

function updateRow_(name, id, updates) {
  const sheet = getSheet_(name);
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const idCol = headers.indexOf('id');
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][idCol]) === String(id)) {
      headers.forEach(function (h, col) {
        if (updates[h] !== undefined) {
          sheet.getRange(i + 1, col + 1).setValue(updates[h]);
        }
      });
      return true;
    }
  }
  return false;
}

function deleteRow_(name, id) {
  const sheet = getSheet_(name);
  const values = sheet.getDataRange().getValues();
  const idCol = values[0].indexOf('id');
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][idCol]) === String(id)) {
      sheet.deleteRow(i + 1);
      return true;
    }
  }
  return false;
}

function getConfig_() {
  const objs = sheetToObjects_('Config');
  const cfg = {};
  objs.forEach(function (o) { cfg[o.key] = o.value; });
  return cfg;
}

function setConfig_(updates) {
  const sheet = getSheet_('Config');
  const values = sheet.getDataRange().getValues();
  const existingKeys = values.slice(1).map(function (r) { return r[0]; });
  Object.keys(updates).forEach(function (k) {
    const idx = existingKeys.indexOf(k);
    if (idx !== -1) {
      sheet.getRange(idx + 2, 2).setValue(updates[k]);
    } else {
      sheet.appendRow([k, updates[k]]);
    }
  });
  return getConfig_();
}

// ------------------------------------------------------------------
// API ROUTER
// ------------------------------------------------------------------

function doGet(e) {
  const params = e.parameter;
  const action = params.action || 'getAll';
  let result;

  try {
    result = route_(action, params);
  } catch (err) {
    result = { error: String(err) };
  }

  const json = JSON.stringify(result);
  if (params.callback) {
    return ContentService
      .createTextOutput(params.callback + '(' + json + ')')
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService
    .createTextOutput(json)
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  // Allow POST with JSON body as an alternative to GET+JSONP
  const params = JSON.parse(e.postData.contents);
  const action = params.action || 'getAll';
  let result;
  try {
    result = route_(action, params);
  } catch (err) {
    result = { error: String(err) };
  }
  return ContentService
    .createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}

function route_(action, params) {
  const data = params.data ? JSON.parse(params.data) : {};

  switch (action) {
    case 'getAll':
      return getAllData_();

    case 'getConfig':
      return getConfig_();

    case 'updateConfig':
      return setConfig_(data);

    case 'add':
      return appendRow_(params.sheet, data);

    case 'update':
      return { ok: updateRow_(params.sheet, params.id, data) };

    case 'delete':
      return { ok: deleteRow_(params.sheet, params.id) };

    case 'list':
      return sheetToObjects_(params.sheet);

    default:
      return { error: 'Acción desconocida: ' + action };
  }
}

function getAllData_() {
  const out = { config: getConfig_() };
  Object.keys(SHEETS).forEach(function (name) {
    if (name === 'Config') return;
    out[name] = sheetToObjects_(name);
  });
  return out;
}
